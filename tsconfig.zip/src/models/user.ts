import { DataTypes } from "sequelize";

import sequelize from "../connection";
import { Order } from "./order";

const User = sequelize.define("User", {
  id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  },
  username: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  email: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  password: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  confirm_password: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  token: {
    type: DataTypes.STRING,
  },
  phonenum: {
    type: DataTypes.FLOAT,
  },
  city: {
    type: DataTypes.STRING,
  },

  address: {
    type: DataTypes.STRING,
  },

  country: {
    type: DataTypes.STRING,
  },

  zipCode: {
    type: DataTypes.STRING,
    field: "zip_code",
  },
  role : {
    type : DataTypes.ENUM('ADMIN' , 'USER') ,
    defaultValue : 'USER'
    
  }
});

// User.hasMany(Order, {
//   foreignKey: "userId",
// });

// User.hasMany(Order, { foreignKey: "orderId" });

User.sync();

export { sequelize, User };
