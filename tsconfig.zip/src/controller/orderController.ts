import { Order } from "../models/order";

import { Request, Response } from "express";
import { Product } from "../models/product";
import { orderValidation } from "../request/orderValidation";
import { User } from "../models/user";
import { Cart } from "../models/cart";
import Razorpay from "razorpay";

var instance = new Razorpay({
  key_id: "rzp_test_Ls1Ugr8RHpdrw2",
  key_secret: "482rN744FqAi8h0tLUD2adyd",
});

class orderController {
  // static addToCart = async (req: Request, res: Response) => {
  //   try {
  //     const { userId, productId, quantity } = req.body;

  //     // Check if the product exists and has enough stock
  //     const product = await Product.findByPk(productId);
  //     console.log(product);

  //     if (!product) {
  //       return res.status(404).json({ error: "Product not found" });
  //     }
  //     if (product.dataValues.stock < quantity) {
  //       return res.status(400).json({ error: "Insufficient stock" });
  //     }

  //     // Create a new cart item
  //     const cartItem = await Order.create({
  //       productId,
  //       userId,
  //       quantity,
  //     });

  //     return res.status(200).json({ success: true, cartItem });
  //   } catch (error) {
  //     console.error(error);
  //     return res.status(500).json({ error });
  //   }
  // };

  // static getUserCart = async (req: Request, res: Response) => {
  //   try {
  //     const { userId } = req.params;

  //     // Find the user and include their cart and associated products
  //     const user = await User.findByPk(userId, {
  //       include: [
  //         {
  //           model: Order,
  //           as: "Orders",
  //           include: [
  //             {
  //               model: Product,
  //               as: "products",
  //             },
  //           ],
  //         },
  //       ],
  //     });
  //     console.log(user);

  //     if (!user) {
  //       return res.status(404).json({ error: "User not found" });
  //     }
  //    // cart with items and price
  //     const userCart = user.getDataValue("Orders").map((order: any) => {
  //       const { id, orderTime, products } = order;

  //       const cartItems = products.map((product: any) => {
  //         const { id: productId, name, price } = product;

  //         return {
  //           productId,
  //           name,
  //           price,
  //         };
  //       });

  //       return {
  //         id,
  //         orderTime,
  //         cartItems,
  //       };
  //     });

  //     console.log(userCart);

  //     return res.status(200).json({ userCart });
  //   } catch (error) {
  //     console.error(error);
  //     return res.status(500).json({ error });
  //   }
  // };

  static createOrder = async (req: Request, res: Response) => {
    const { address, mobile, paymentMethod, paymentId, price, creditCard, cvv, upiId } = req.body;
    const userId = req.body.id;
    let totalPrice = 0;
  
    try {
      // Find cart
      const cartProduct = await Cart.findAll({ where: { userId } });
  
      if (!cartProduct.length) {
        res.status(404).json({ error: "Cart is empty" });
        return;
      }
  
      // Extract product details from cart items
      const products = cartProduct.map((cartProduct) => {
        const { productId, quantity, price } = cartProduct.dataValues;
        totalPrice += price;
        return {
          productId,
          quantity,
          price,
        };
      });
  
      // Create the order
      const order = await Order.create({
        userId,
        products,
        paymentMethod,
        price: totalPrice,
        paymentId: null,
        creditCard: null,
        cvv: null,
        upiId: null,
      });
  
      // Destroy cart items
      await Cart.destroy({
        where: {
          userId,
        },
      });
  
      if (paymentMethod === "COD") {
        // Cash on Delivery payment method
        res.json({
          message: "Order created successfully",
          order,
          products,
          totalPrice,
        });
      } else if (paymentMethod === "CARD") {
        // Card Payment method
        if (!creditCard || !cvv) {
          res.status(400).json({ error: "Credit card details missing" });
          return;
        }
  
        // Process the card payment here
        // ...
  
        // Save the payment ID in the order model
        order.setDataValue("paymentId", paymentId);
        order.dataValues.paymentId = paymentId;
  
        // Save the credit card and CVV in the order model
        order.setDataValue("creditCard", creditCard);
        order.dataValues.creditCard = creditCard;
        order.setDataValue("cvv", cvv);
        order.dataValues.cvv = cvv;
  
        await order.save();
  
        res.json({
          message: "Order created successfully",
          order,
          products,
          totalPrice,
          paymentId,
        });
      } else if (paymentMethod === "ONLINE") {
        // Online Payment method (Razorpay)
        const razorpayOrder = await instance.orders.create({
          amount: totalPrice * 100,
          currency: "INR",
          receipt: order.dataValues.id,
        });

        // Save the payment ID in the order model
        const payment = razorpayOrder.id;
        order.setDataValue("paymentId", payment);
        order.dataValues.paymentId = payment;

        await order.save();

        res.json({
          message: "Order created successfully",
          order,
          products,
          totalPrice,
          paymentId: payment,
        });
      } else {
        res.status(400).json({ error: "Invalid payment method" });
      }
    } catch (error) {
      console.log(error);
    }
  };
  

  static getOrder = async (req: Request, res: Response): Promise<void> => {
    const userId = req.body.id;

    try {
      // Create the order
      const order = await Order.findAll({
        where: { userId: userId },
      });

      res.json({ order });
    } catch (error) {
      console.log(error);
    }
  };

  static getOrderUser = async (req: Request, res: Response) => {
    const { id } = req.params;
    try {
      const order = await Order.findAll({
        include: [
          {
            model: Product,
            as: "products",
            attributes: ["id", "name", "price", "productimage"],
          },
        ],
        where: { userId: id },
      });

      if (order) {
        const user = await User.findOne({
          where: { id },
        });
        res.json({ users: user, orders: order });
      }
    } catch (error) {
      console.log(error);
    }
  };

  static makePayment = async (req: Request, res: Response) => {
    try {
      const { orderId, userId } = req.body;
      const user = await User.findByPk(userId);

      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      const order = await Order.findByPk(orderId);

      console.log(order, ";;;;;;;;order");

      if (!order) {
        return res.status(404).json({ error: "Order not found" });
      }

      // Perform payment processing here using your preferred payment gateway or method

      // Assuming the payment is successful, update the order status to "paid"
      // order.status = 'paid';
      await order.save();

      return res
        .status(200)
        .json({ success: true, message: "Payment successful" });
    } catch (error) {
      console.error(error);
      return res.status(500).json({ error: "Server error" });
    }
  };
}

export { orderController };
